<?php

    function generateFooter(){
        echo '
        <footer class="footer py-5 bg-dark text-center">
            <span class="text-white">Made with <span style="color:red;">♥</span> by Fadel Azzahra</span>
            <br>
            <span class="text-white">Copyright © 2023</span>
        </footer>
        ';
    }
?>